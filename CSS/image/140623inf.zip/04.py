lst = []
for i in range(101):
    a = int(input())
    if a == 0:
        break
    if a > 9 and a < 100:
        lst.append(a)

if len(lst) == 0:
    print("NO")
else:
    print(sum(lst) / len(lst))
